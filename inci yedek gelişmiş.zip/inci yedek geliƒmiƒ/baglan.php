﻿<?php 
$username="";
$password="";
$sunucu="";
$database="";

$baglan= @mysql_connect($sunucu,$username,$password);
mysql_query("SET NAMES UTF8");

if (!$baglan) {
	echo "Maalesef veritabanına bağlanamadı. Lütfen yazılımcınız ile iletişime geçin".mysql_errno();
}

$db=mysql_select_db($database);

if (!$db) {
 	echo "Veriniz güncellenemedi. Lüften yazılımcınız ile iletişime geçin".mysql_error();
 	echo "<br>";
}
?>