<?php
// Yetki kontrol
session_start();
?>
<meta charset="utf-8"><body style="background-color:#ccc"><center>
<?
if ( $_SESSION["giris_basarili"] != TRUE ){
echo "<a href='cikis.php'>Cikis yap</a></div><p>Bu sayfayi goruntuleme yetkiniz yok.</p>";
exit();
}

// vt ba&#287;lant&#305;s&#305;n&#305; kuruyoruz.
include("baglan.php");

$id = $_GET["entari_id"];

// VT kay&#305;kliyoruz.
$sql = "DELETE FROM entariler WHERE entari_id=$id ";

if ( mysql_query( $sql ) ){
echo "$id <br><center><h1>$id. entry silindi.</h1></center>";
include("yonetim.php");
} else {
echo "<br>Sorgu hata verdi.";
}
?>