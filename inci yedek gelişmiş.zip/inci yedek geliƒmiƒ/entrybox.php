<form action="islem.php" method="POST">
<ul class="buttons">
<li><button class="buttonstyle" style="float:right;">*</button></li>
<li><button class="buttonstyle" style="float:right;">-!sl-</button></li>
<li><button class="buttonstyle" style="float:right;">' '</button></li>
<li><button class="buttonstyle" style="float:right;">(bkz:</button></li>
</ul>
<textarea autofocus name="entari_mesaj" class="textarea" placeholder="Yazın..."></textarea>
<ul>
<li><button class="buttonstyle" type="submit" name="ekle" value="kaydet" style="float:left;margin-right:5px">yolla panpa</button></li>
<li><button class="buttonstyle"  style="float:left">caps</button></li>
</ul>
</form>
</div><br><br><br>
</body>
</html>