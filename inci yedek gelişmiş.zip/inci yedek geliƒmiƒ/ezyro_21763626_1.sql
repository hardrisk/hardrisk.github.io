﻿-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: sql210.ezyro.com
-- Generation Time: Nov 25, 2018 at 04:22 PM
-- Server version: 5.6.41-84.1
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ezyro_21763626_1`
--

-- --------------------------------------------------------

--
-- Table structure for table `baslik`
--

CREATE TABLE IF NOT EXISTS `baslik` (
  `baslik` varchar(50) COLLATE utf32_turkish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf32 COLLATE=utf32_turkish_ci;

--
-- Dumping data for table `baslik`
--

INSERT INTO `baslik` (`baslik`) VALUES
('Merhaba');

-- --------------------------------------------------------

--
-- Table structure for table `entariler`
--

CREATE TABLE IF NOT EXISTS `entariler` (
  `entari_id` int(11) NOT NULL AUTO_INCREMENT,
  `entari_mesaj` varchar(1000) COLLATE utf32_turkish_ci NOT NULL,
  PRIMARY KEY (`entari_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf32 COLLATE=utf32_turkish_ci AUTO_INCREMENT=42 ;

--
-- Dumping data for table `entariler`
--

INSERT INTO `entariler` (`entari_id`, `entari_mesaj`) VALUES
(11, '55555'),
(12, '<a href="https://www.youtube.com/watch?v=KNZH-emehxA">Shania Twain - Youre Still The One - YouTube</a><br>\r\n'),
(13, 'https://www.youtube.com/watch?v=B4X4rdyXIEw">sdd'),
(14, 'https://www.youtube.com/watch?v=B4X4rdyXIEw'),
(16, ''),
(38, 'üüüüüüü'),
(18, ''),
(19, ''),
(20, ''),
(21, ''),
(22, 'sfsfsg\r\n'),
(39, 'oıjıjm'),
(24, 'hakoşşşşşş\r\n'),
(25, 'http://viceveralone.ezyro.com/inci/index.php?durum=yes'),
(40, '1151\r\n'),
(41, '$row'),
(32, '<center> At yarışları modern toplumların gelişmesi için sosyal bir ihtiyaçtır.'),
(33, '<center><div style="color:red"><p>asd</p></div>'),
(34, '<center><div style="color:PURPLE"><p>MUHTEŞEM MESUT</p></div>'),
(35, '<a href="https://www.youtube.com/watch?v=QdGD3Ukb3Q0">Savatage - Hall Of The Mountain King - YouTube</a><br>\r\n'),
(37, '<center>WampServer<br>\r\nXAMPP<br>\r\nAppServ<br>');

-- --------------------------------------------------------

--
-- Table structure for table `kullanicilar`
--

CREATE TABLE IF NOT EXISTS `kullanicilar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kullanici_adi` varchar(30) NOT NULL,
  `parola` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `kullanicilar`
--

INSERT INTO `kullanicilar` (`id`, `kullanici_adi`, `parola`) VALUES
(1, 'admin', 'admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
