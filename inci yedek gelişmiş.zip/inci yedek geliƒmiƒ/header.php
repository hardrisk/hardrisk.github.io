<?php include('sorgular.php') ?>
<html>
<head>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/reset.css">
</head>
<body><div onclick="location.href='giris.html'" style='font-family:"Lucida Console";font-size:20px;line-height:26px;cursor:pointer;z-index:1;background-color:red;text-align:center;position:fixed;bottom:0;right:0;height:26px;width:60px;border:4px solid gray'>G&#304;R&#304;&#350;</div>
<div class="container">