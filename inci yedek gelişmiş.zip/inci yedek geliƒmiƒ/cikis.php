<?php
// cikis.php
session_start();
?>
<meta charset="utf-8">
 
<?php
$_SESSION["giris_basarili"] = NULL; 
session_destroy();
echo "<body bgcolor=' #ccc'><center><h1>C&#305;k&#305;&#351; Yap&#305;ld&#305;</h1>";
echo "<br><a href='yonetimgiris.html'>yonetici giri&#351;i</a><br><a href='index.php'>Ana Sayfa</a></center></body>";
?>


<script type="text/javascript">
    window.setTimeout(function() {
        window.location.href='index.php';
    }, 300);
</script>