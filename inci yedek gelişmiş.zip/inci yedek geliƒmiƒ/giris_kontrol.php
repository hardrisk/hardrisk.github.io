<?php 
session_start();?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<?php
  // vt ba&#287;lant&#305;s&#305;n&#305; kuruyoruz.
  include("baglan.php"); 
   
  // giris_kontrol.php
  $k_adi = $_POST["f_ad"];
  $parola = $_POST["f_parola"];
   
  $sql = " SELECT * FROM kullanicilar
           WHERE kullanici_adi = '$k_adi' AND 
                 parola     = '$parola'"; 
  $results = mysql_query($sql);
  $kayit_sayisi = mysql_num_rows($results);
   
  if ( $kayit_sayisi == 1 ) {
      
     $_SESSION["giris_basarili"] = TRUE;
     echo "<body bgcolor=' #ccc'><center>Giri&#351; Ba&#351;ar&#305;l&#305;";
     echo "<br><a href='yonetim.php'>Yonetim Sayfas&#305;</a></center></body><script type='text/javascript'>
    window.setTimeout(function() {
        window.location.href='yonetim.php';
    }, 300);
</script>";
  } else { 
     echo "<body bgcolor=' #ccc'><center>Kullan&#305;c&#305; ad&#305; ya da parola hatal&#305;<br><br><br><br><br><br><br><br>";
     echo "<a style='text-decoration:none;color:red;font-size:75px' href='yonetimgiris.html'>Tekrar dene</a></center></body><script>
alert('Kullan&#305;c&#305; ad&#305; ya da parola hatal&#305;');
</script>";
  }
 ?>